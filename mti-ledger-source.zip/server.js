const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const crypto = require('node:crypto');
const { promisify } = require('node:util');
const { connectDatabase, runMigrations } = require('./db');

const scrypt = promisify(crypto.scrypt);
const ROOT = __dirname;
const PAYMENT_METHODS = ['Cash', 'Bank', 'bKash', 'Nagad', 'Card', 'Other'];
const SESSION_DAYS = 7;
const loginAttempts = new Map();
const setupTokens = new Map();

function loadDotEnv() {
  const filename = path.join(ROOT, '.env');
  if (!fs.existsSync(filename)) return;
  for (const rawLine of fs.readFileSync(filename, 'utf8').split(/\r?\n/)) {
    const line = rawLine.trim();
    if (!line || line.startsWith('#')) continue;
    const separator = line.indexOf('=');
    if (separator < 1) continue;
    const key = line.slice(0, separator).trim();
    let value = line.slice(separator + 1).trim();
    if ((value.startsWith('"') && value.endsWith('"')) || (value.startsWith("'") && value.endsWith("'"))) value = value.slice(1, -1);
    if (process.env[key] === undefined) process.env[key] = value;
  }
}

loadDotEnv();

const config = {
  port: Number.parseInt(process.env.PORT || '3000', 10),
  databaseUrl: process.env.DATABASE_URL || 'sqlite:./data/ledger.db',
  sessionSecret: process.env.SESSION_SECRET || crypto.randomBytes(32).toString('hex'),
  secretKey: process.env.SECRET_KEY || crypto.randomBytes(32).toString('hex'),
  timezone: process.env.APP_TIMEZONE || 'Asia/Dhaka',
  production: process.env.NODE_ENV === 'production',
  appOrigin: process.env.APP_ORIGIN || ''
};

if (config.production && (!process.env.SESSION_SECRET || !process.env.SECRET_KEY)) {
  throw new Error('SESSION_SECRET and SECRET_KEY must be set in production.');
}

function now() {
  return new Date().toISOString();
}

function dateInTimezone(date = new Date()) {
  const parts = new Intl.DateTimeFormat('en-CA', {
    timeZone: config.timezone,
    year: 'numeric', month: '2-digit', day: '2-digit'
  }).formatToParts(date);
  const value = Object.fromEntries(parts.filter((part) => part.type !== 'literal').map((part) => [part.type, part.value]));
  return `${value.year}-${value.month}-${value.day}`;
}

function nextMonth(month) {
  const [year, monthNumber] = month.split('-').map(Number);
  const base = new Date(Date.UTC(year, monthNumber, 1));
  return base.toISOString().slice(0, 7);
}

function weekBounds() {
  const today = dateInTimezone();
  const date = new Date(`${today}T00:00:00Z`);
  const sundayOffset = date.getUTCDay();
  const mondayOffset = sundayOffset === 0 ? -6 : 1 - sundayOffset;
  date.setUTCDate(date.getUTCDate() + mondayOffset);
  const from = date.toISOString().slice(0, 10);
  date.setUTCDate(date.getUTCDate() + 7);
  return { from, toExclusive: date.toISOString().slice(0, 10) };
}

function randomToken(bytes = 32) {
  return crypto.randomBytes(bytes).toString('base64url');
}

function hashSessionId(sessionId) {
  return crypto.createHmac('sha256', config.sessionSecret).update(sessionId).digest('hex');
}

async function hashPassword(password) {
  const salt = crypto.randomBytes(16).toString('base64url');
  const derived = await scrypt(password, salt, 64);
  return `scrypt$${salt}$${Buffer.from(derived).toString('base64url')}`;
}

async function passwordMatches(password, stored) {
  const [scheme, salt, encoded] = String(stored).split('$');
  if (scheme !== 'scrypt' || !salt || !encoded) return false;
  const expected = Buffer.from(encoded, 'base64url');
  const actual = Buffer.from(await scrypt(password, salt, 64));
  return actual.length === expected.length && crypto.timingSafeEqual(actual, expected);
}

function parseCookies(request) {
  const result = {};
  for (const item of String(request.headers.cookie || '').split(';')) {
    const separator = item.indexOf('=');
    if (separator < 1) continue;
    const key = item.slice(0, separator).trim();
    try { result[key] = decodeURIComponent(item.slice(separator + 1).trim()); } catch { /* ignore a malformed cookie */ }
  }
  return result;
}

function cookie(name, value, maxAge = 0) {
  const parts = [`${name}=${encodeURIComponent(value)}`, 'Path=/', 'HttpOnly', 'SameSite=Lax'];
  if (maxAge > 0) parts.push(`Max-Age=${maxAge}`);
  if (maxAge === -1) parts.push('Max-Age=0');
  if (config.production) parts.push('Secure');
  return parts.join('; ');
}

function baseHeaders(response) {
  response.setHeader('X-Content-Type-Options', 'nosniff');
  response.setHeader('X-Frame-Options', 'DENY');
  response.setHeader('Referrer-Policy', 'no-referrer');
  response.setHeader('Permissions-Policy', 'camera=(), microphone=(), geolocation=()');
  response.setHeader('Cross-Origin-Opener-Policy', 'same-origin');
  response.setHeader('Content-Security-Policy', "default-src 'self'; base-uri 'self'; form-action 'self'; frame-ancestors 'none'; object-src 'none'; script-src 'self'; style-src 'self'; connect-src 'self'");
}

function sendJson(response, status, data, extraHeaders = {}) {
  baseHeaders(response);
  response.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store', ...extraHeaders });
  response.end(JSON.stringify(data));
}

function sendText(response, status, body, contentType, extraHeaders = {}) {
  baseHeaders(response);
  response.writeHead(status, { 'Content-Type': contentType, ...extraHeaders });
  response.end(body);
}

function apiError(response, status, message, fieldErrors) {
  return sendJson(response, status, { error: message, ...(fieldErrors ? { fieldErrors } : {}) });
}

function requestIp(request) {
  return String(request.headers['x-forwarded-for'] || request.socket.remoteAddress || '').split(',')[0].trim();
}

function canAttemptLogin(ip) {
  const current = Date.now();
  const item = loginAttempts.get(ip);
  if (!item) return true;
  if (item.blockedUntil > current) return false;
  if (current - item.startedAt > 10 * 60 * 1000) { loginAttempts.delete(ip); return true; }
  return true;
}

function failedLogin(ip) {
  const current = Date.now();
  const item = loginAttempts.get(ip) || { count: 0, startedAt: current, blockedUntil: 0 };
  if (current - item.startedAt > 10 * 60 * 1000) { item.count = 0; item.startedAt = current; }
  item.count += 1;
  if (item.count >= 5) item.blockedUntil = current + 15 * 60 * 1000;
  loginAttempts.set(ip, item);
}

function successfulLogin(ip) {
  loginAttempts.delete(ip);
}

async function readJson(request) {
  const contentType = String(request.headers['content-type'] || '');
  if (!contentType.includes('application/json')) throw Object.assign(new Error('Request must use JSON.'), { status: 415 });
  let body = '';
  for await (const chunk of request) {
    body += chunk;
    if (Buffer.byteLength(body) > 10 * 1024 * 1024) throw Object.assign(new Error('Request is too large.'), { status: 413 });
  }
  if (!body) return {};
  try { return JSON.parse(body); } catch { throw Object.assign(new Error('Invalid JSON data.'), { status: 400 }); }
}

function nonEmpty(value, field, limit = 1000) {
  if (typeof value !== 'string' || !value.trim()) throw Object.assign(new Error(`${field} is required.`), { status: 400 });
  const cleaned = value.trim();
  if (cleaned.length > limit) throw Object.assign(new Error(`${field} is too long.`), { status: 400 });
  return cleaned;
}

function optionalText(value, field, limit) {
  if (value === undefined || value === null || value === '') return null;
  if (typeof value !== 'string') throw Object.assign(new Error(`${field} is invalid.`), { status: 400 });
  const cleaned = value.trim();
  if (cleaned.length > limit) throw Object.assign(new Error(`${field} is too long.`), { status: 400 });
  return cleaned || null;
}

function validateDate(value) {
  if (typeof value !== 'string' || !/^\d{4}-\d{2}-\d{2}$/.test(value) || Number.isNaN(Date.parse(`${value}T00:00:00Z`))) {
    throw Object.assign(new Error('A valid date is required.'), { status: 400 });
  }
  return value;
}

function parseAmountPaisa(value) {
  const input = String(value ?? '').trim();
  if (!/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(input)) throw Object.assign(new Error('Amount must be a valid positive number.'), { status: 400 });
  const [whole, decimals = ''] = input.split('.');
  const paisa = BigInt(whole) * 100n + BigInt((decimals + '00').slice(0, 2));
  if (paisa <= 0n || paisa > 9999999999n) throw Object.assign(new Error('Amount must be greater than zero and within the allowed limit.'), { status: 400 });
  return Number(paisa);
}

function validateExpense(input) {
  const typeId = Number.parseInt(String(input.expense_type_id), 10);
  if (!Number.isSafeInteger(typeId) || typeId < 1) throw Object.assign(new Error('Expense type is required.'), { status: 400 });
  const paymentMethod = String(input.payment_method || '');
  if (!PAYMENT_METHODS.includes(paymentMethod)) throw Object.assign(new Error('Payment method is required.'), { status: 400 });
  return {
    expense_date: validateDate(input.expense_date),
    expense_type_id: typeId,
    description: nonEmpty(input.description, 'Description', 240),
    amount_paisa: parseAmountPaisa(input.amount),
    payment_method: paymentMethod,
    paid_to: optionalText(input.paid_to, 'Paid To', 160),
    note: optionalText(input.note, 'Note', 1000)
  };
}

function normalDate(value) {
  if (value instanceof Date) return value.toISOString().slice(0, 10);
  return String(value).slice(0, 10);
}

function serializeExpense(row) {
  return {
    id: Number(row.id),
    expense_date: normalDate(row.expense_date),
    expense_type_id: Number(row.expense_type_id),
    expense_type: row.expense_type,
    description: row.description,
    amount_paisa: Number(row.amount_paisa),
    payment_method: row.payment_method,
    paid_to: row.paid_to || '',
    note: row.note || '',
    external_ref: row.external_ref,
    created_at: row.created_at,
    updated_at: row.updated_at
  };
}

const EXPENSE_FIELDS = `
  SELECT e.id, e.expense_date, e.expense_type_id, t.name AS expense_type, e.description,
         e.amount_paisa, e.payment_method, e.paid_to, e.note, e.external_ref, e.created_at, e.updated_at
  FROM expenses e JOIN expense_types t ON t.id = e.expense_type_id`;

async function createSession(db, userId) {
  const sessionId = randomToken();
  const csrfToken = randomToken();
  const createdAt = now();
  const expiresAt = new Date(Date.now() + SESSION_DAYS * 86400 * 1000).toISOString();
  await db.run('INSERT INTO sessions (id_hash, user_id, csrf_token, expires_at, created_at, last_used_at) VALUES (?, ?, ?, ?, ?, ?)',
    [hashSessionId(sessionId), userId, csrfToken, expiresAt, createdAt, createdAt]);
  return { sessionId, csrfToken };
}

async function getAuth(db, request) {
  const sessionId = parseCookies(request).ledger_session;
  if (!sessionId) return null;
  const session = await db.one(`SELECT s.id_hash, s.csrf_token, s.expires_at, u.id AS user_id, u.username, u.role
    FROM sessions s JOIN users u ON u.id = s.user_id WHERE s.id_hash = ?`, [hashSessionId(sessionId)]);
  if (!session) return null;
  if (new Date(session.expires_at).getTime() <= Date.now()) {
    await db.run('DELETE FROM sessions WHERE id_hash = ?', [session.id_hash]);
    return null;
  }
  await db.run('UPDATE sessions SET last_used_at = ? WHERE id_hash = ?', [now(), session.id_hash]);
  return { session, user: { id: Number(session.user_id), username: session.username, role: session.role } };
}

function trustedOrigin(request) {
  const origin = request.headers.origin;
  if (!origin) return true;
  if (config.appOrigin) return origin === config.appOrigin;
  try { return new URL(origin).host === request.headers.host; } catch { return false; }
}

async function requireAuth(db, request, response, needsCsrf = false) {
  const auth = await getAuth(db, request);
  if (!auth) { apiError(response, 401, 'Please log in to continue.'); return null; }
  if (needsCsrf && (!trustedOrigin(request) || request.headers['x-csrf-token'] !== auth.session.csrf_token)) {
    apiError(response, 403, 'Your session could not be verified. Refresh the page and try again.'); return null;
  }
  return auth;
}

function requireAdmin(auth, response) {
  if (auth.user.role !== 'admin') { apiError(response, 403, 'Admin access is required.'); return false; }
  return true;
}

async function logAudit(db, userId, action, entityType, entityId, details = null) {
  await db.run('INSERT INTO audit_logs (user_id, action, entity_type, entity_id, details, created_at) VALUES (?, ?, ?, ?, ?, ?)',
    [userId, action, entityType, entityId === null ? null : String(entityId), details ? JSON.stringify(details) : null, now()]);
}

async function activeTypeOrError(db, typeId) {
  const type = await db.one('SELECT id, name, is_active FROM expense_types WHERE id = ?', [typeId]);
  if (!type || !Boolean(type.is_active)) throw Object.assign(new Error('Choose an active expense type.'), { status: 400 });
  return type;
}

function getExpenseFilters(url) {
  const range = url.searchParams.get('range') || 'this-month';
  const clauses = [];
  const params = [];
  let from = '';
  let to = '';
  if (range === 'today') { from = dateInTimezone(); to = from; }
  else if (range === 'this-week') { const bounds = weekBounds(); from = bounds.from; to = bounds.toExclusive; }
  else if (range === 'this-month') { const month = dateInTimezone().slice(0, 7); from = `${month}-01`; to = nextMonth(month); }
  else if (range === 'custom') {
    from = url.searchParams.get('from') || '';
    to = url.searchParams.get('to') || '';
    if (from) validateDate(from);
    if (to) validateDate(to);
    if (from && to && from > to) throw Object.assign(new Error('From date cannot be after To date.'), { status: 400 });
  } else if (range !== 'all') throw Object.assign(new Error('Invalid date filter.'), { status: 400 });

  if (from) { clauses.push('e.expense_date >= ?'); params.push(from); }
  if (to) {
    if (range === 'this-week' || range === 'this-month') { clauses.push('e.expense_date < ?'); params.push(to); }
    else { clauses.push('e.expense_date <= ?'); params.push(to); }
  }
  const search = (url.searchParams.get('q') || '').trim();
  if (search) {
    clauses.push('(LOWER(e.description) LIKE LOWER(?) OR LOWER(COALESCE(e.paid_to, \'\')) LIKE LOWER(?) OR LOWER(t.name) LIKE LOWER(?))');
    const wildcard = `%${search.slice(0, 100)}%`;
    params.push(wildcard, wildcard, wildcard);
  }
  return { where: clauses.length ? ` WHERE ${clauses.join(' AND ')}` : '', params, range, from, to, search };
}

async function totals(db, where = '', params = []) {
  const rows = await db.all(`SELECT e.payment_method, COALESCE(SUM(e.amount_paisa), 0) AS total FROM expenses e ${where} GROUP BY e.payment_method`, params);
  const payments = Object.fromEntries(PAYMENT_METHODS.map((method) => [method, 0]));
  let total = 0;
  for (const row of rows) { payments[row.payment_method] = Number(row.total); total += Number(row.total); }
  return { total, payments };
}

function csvValue(value) {
  const text = String(value ?? '');
  return /[",\n\r]/.test(text) ? `"${text.replace(/"/g, '""')}"` : text;
}

function expenseToBackup(row) {
  const item = serializeExpense(row);
  return {
    external_ref: item.external_ref,
    expense_date: item.expense_date,
    expense_type: item.expense_type,
    description: item.description,
    amount_paisa: item.amount_paisa,
    payment_method: item.payment_method,
    paid_to: item.paid_to,
    note: item.note,
    created_at: item.created_at,
    updated_at: item.updated_at
  };
}

function isUuid(value) {
  return typeof value === 'string' && /^[0-9a-f]{8}-[0-9a-f]{4}-[1-5][0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i.test(value);
}

async function importBackup(db, userId, payload) {
  if (!payload || payload.backup_version !== 1 || !Array.isArray(payload.expenses)) {
    throw Object.assign(new Error('This is not a valid Office Expense Ledger JSON backup.'), { status: 400 });
  }
  if (payload.expenses.length > 50000 || (payload.expense_types && !Array.isArray(payload.expense_types))) {
    throw Object.assign(new Error('Backup has an invalid number of records.'), { status: 400 });
  }
  const incomingTypes = Array.isArray(payload.expense_types) ? payload.expense_types : [];
  const normalizedTypes = incomingTypes.map((item) => ({ name: nonEmpty(item.name, 'Expense type', 80), is_active: item.is_active !== false }));
  const preparedExpenses = payload.expenses.map((item) => {
    if (!isUuid(item.external_ref)) throw Object.assign(new Error('Backup contains an invalid expense reference.'), { status: 400 });
    const amount = Number(item.amount_paisa);
    if (!Number.isSafeInteger(amount) || amount <= 0 || amount > 9999999999) throw Object.assign(new Error('Backup contains an invalid amount.'), { status: 400 });
    if (!PAYMENT_METHODS.includes(item.payment_method)) throw Object.assign(new Error('Backup contains an invalid payment method.'), { status: 400 });
    return {
      external_ref: item.external_ref,
      expense_date: validateDate(item.expense_date),
      expense_type: nonEmpty(item.expense_type, 'Expense type', 80),
      description: nonEmpty(item.description, 'Description', 240),
      amount_paisa: amount,
      payment_method: item.payment_method,
      paid_to: optionalText(item.paid_to, 'Paid To', 160),
      note: optionalText(item.note, 'Note', 1000),
      created_at: typeof item.created_at === 'string' ? item.created_at : now(),
      updated_at: typeof item.updated_at === 'string' ? item.updated_at : now()
    };
  });

  return db.transaction(async (tx) => {
    const existingTypes = await tx.all('SELECT id, name FROM expense_types');
    const typeMap = new Map(existingTypes.map((item) => [item.name.toLocaleLowerCase(), Number(item.id)]));
    for (const type of [...normalizedTypes, ...preparedExpenses.map((item) => ({ name: item.expense_type, is_active: true }))]) {
      const key = type.name.toLocaleLowerCase();
      if (!typeMap.has(key)) {
        const created = await tx.one('INSERT INTO expense_types (name, is_active, created_at, updated_at) VALUES (?, ?, ?, ?) RETURNING id',
          [type.name, type.is_active ? 1 : 0, now(), now()]);
        typeMap.set(key, Number(created.id));
      }
    }
    let imported = 0;
    let skipped = 0;
    for (const item of preparedExpenses) {
      const exists = await tx.one('SELECT id FROM expenses WHERE external_ref = ?', [item.external_ref]);
      if (exists) { skipped += 1; continue; }
      await tx.run(`INSERT INTO expenses (expense_date, expense_type_id, description, amount_paisa, payment_method, paid_to, note, external_ref, created_at, updated_at)
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)`,
      [item.expense_date, typeMap.get(item.expense_type.toLocaleLowerCase()), item.description, item.amount_paisa, item.payment_method,
        item.paid_to, item.note, item.external_ref, item.created_at, item.updated_at]);
      imported += 1;
    }
    await logAudit(tx, userId, 'IMPORT', 'backup', null, { imported, skipped });
    return { imported, skipped };
  });
}

function staticFile(response, filename, contentType) {
  const filepath = path.join(ROOT, 'public', filename);
  if (!fs.existsSync(filepath)) return sendText(response, 404, 'Not found', 'text/plain; charset=utf-8');
  sendText(response, 200, fs.readFileSync(filepath), contentType, { 'Cache-Control': 'no-cache' });
}

async function createApp() {
  const db = await connectDatabase(config.databaseUrl, ROOT);
  await runMigrations(db, ROOT);

  async function handler(request, response) {
    const url = new URL(request.url, `http://${request.headers.host || 'localhost'}`);
    const pathname = url.pathname;
    try {
      if (request.method === 'GET' && pathname === '/') return staticFile(response, 'index.html', 'text/html; charset=utf-8');
      if (request.method === 'GET' && pathname === '/style.css') return staticFile(response, 'style.css', 'text/css; charset=utf-8');
      if (request.method === 'GET' && pathname === '/app.js') return staticFile(response, 'app.js', 'application/javascript; charset=utf-8');
      if (request.method === 'GET' && pathname === '/assets/mti-logo.png') return staticFile(response, 'assets/mti-logo.png', 'image/png');
      if (request.method === 'GET' && pathname === '/assets/mti-travel-banner.png') return staticFile(response, 'assets/mti-travel-banner.png', 'image/png');
      if (request.method === 'GET' && pathname === '/health') return sendJson(response, 200, { status: 'ok' });

      if (request.method === 'GET' && pathname === '/api/auth/status') {
        const userCount = await db.one('SELECT COUNT(*) AS count FROM users');
        if (Number(userCount.count) === 0) {
          const existing = parseCookies(request).ledger_setup;
          const token = existing && setupTokens.get(existing)?.expires > Date.now() ? existing : randomToken();
          setupTokens.set(token, { expires: Date.now() + 15 * 60 * 1000 });
          return sendJson(response, 200, { needs_setup: true, setup_token: token }, { 'Set-Cookie': cookie('ledger_setup', token, 15 * 60) });
        }
        const auth = await getAuth(db, request);
        return sendJson(response, 200, auth ? { authenticated: true, user: auth.user, csrf_token: auth.session.csrf_token } : { authenticated: false });
      }

      if (request.method === 'POST' && pathname === '/api/auth/setup') {
        const userCount = await db.one('SELECT COUNT(*) AS count FROM users');
        if (Number(userCount.count) !== 0) return apiError(response, 409, 'Initial setup has already been completed.');
        const input = await readJson(request);
        const setupToken = String(input.setup_token || '');
        const stored = setupTokens.get(setupToken);
        if (!stored || stored.expires < Date.now() || parseCookies(request).ledger_setup !== setupToken || !trustedOrigin(request)) {
          return apiError(response, 403, 'Setup verification failed. Refresh the page and try again.');
        }
        const username = nonEmpty(input.username, 'Username', 50);
        if (!/^[A-Za-z0-9._-]{3,50}$/.test(username)) return apiError(response, 400, 'Username must use 3–50 letters, numbers, dot, underscore, or dash.');
        const password = nonEmpty(input.password, 'Password', 200);
        if (password.length < 10) return apiError(response, 400, 'Password must be at least 10 characters long.');
        const createdAt = now();
        const user = await db.one('INSERT INTO users (username, password_hash, role, created_at, updated_at) VALUES (?, ?, ?, ?, ?) RETURNING id, username, role',
          [username, await hashPassword(password), 'admin', createdAt, createdAt]);
        await logAudit(db, Number(user.id), 'SETUP', 'user', user.id);
        const session = await createSession(db, Number(user.id));
        setupTokens.delete(setupToken);
        return sendJson(response, 201, { message: 'Admin account created.', user: { id: Number(user.id), username: user.username, role: user.role }, csrf_token: session.csrfToken },
          { 'Set-Cookie': [cookie('ledger_session', session.sessionId, SESSION_DAYS * 86400), cookie('ledger_setup', '', -1)] });
      }

      if (request.method === 'POST' && pathname === '/api/auth/login') {
        const ip = requestIp(request);
        if (!canAttemptLogin(ip)) return apiError(response, 429, 'Too many failed attempts. Please wait 15 minutes before trying again.');
        const input = await readJson(request);
        const username = nonEmpty(input.username, 'Username', 50);
        const password = nonEmpty(input.password, 'Password', 200);
        const user = await db.one('SELECT id, username, password_hash, role FROM users WHERE username = ?', [username]);
        if (!user || !(await passwordMatches(password, user.password_hash))) {
          failedLogin(ip);
          return apiError(response, 401, 'Invalid username or password.');
        }
        successfulLogin(ip);
        const session = await createSession(db, Number(user.id));
        await logAudit(db, Number(user.id), 'LOGIN', 'session', null);
        return sendJson(response, 200, { message: 'Welcome back.', user: { id: Number(user.id), username: user.username, role: user.role }, csrf_token: session.csrfToken },
          { 'Set-Cookie': cookie('ledger_session', session.sessionId, SESSION_DAYS * 86400) });
      }

      if (request.method === 'POST' && pathname === '/api/auth/logout') {
        const auth = await requireAuth(db, request, response, true);
        if (!auth) return;
        await db.run('DELETE FROM sessions WHERE id_hash = ?', [auth.session.id_hash]);
        await logAudit(db, auth.user.id, 'LOGOUT', 'session', null);
        return sendJson(response, 200, { message: 'Logged out.' }, { 'Set-Cookie': cookie('ledger_session', '', -1) });
      }

      if (request.method === 'GET' && pathname === '/api/dashboard') {
        const auth = await requireAuth(db, request, response);
        if (!auth) return;
        const today = dateInTimezone();
        const month = today.slice(0, 7);
        const [todayTotal, monthTotal, allTotal, visaTotal, recent] = await Promise.all([
          db.one('SELECT COALESCE(SUM(amount_paisa), 0) AS total FROM expenses WHERE expense_date = ?', [today]),
          db.one('SELECT COALESCE(SUM(amount_paisa), 0) AS total FROM expenses WHERE expense_date >= ? AND expense_date < ?', [`${month}-01`, nextMonth(month)]),
          db.one('SELECT COALESCE(SUM(amount_paisa), 0) AS total FROM expenses'),
          db.one(`SELECT COALESCE(SUM(e.amount_paisa), 0) AS total FROM expenses e JOIN expense_types t ON t.id = e.expense_type_id WHERE t.name = ?`, ['Visa Fee']),
          db.all(`${EXPENSE_FIELDS} ORDER BY e.expense_date DESC, e.id DESC LIMIT 8`)
        ]);
        return sendJson(response, 200, { today_paisa: Number(todayTotal.total), month_paisa: Number(monthTotal.total), total_paisa: Number(allTotal.total), visa_fee_paisa: Number(visaTotal.total), recent: recent.map(serializeExpense) });
      }

      if (request.method === 'GET' && pathname === '/api/expense-types') {
        const auth = await requireAuth(db, request, response);
        if (!auth) return;
        const includeInactive = url.searchParams.get('all') === 'true';
        const list = await db.all(`SELECT id, name, is_active, created_at, updated_at FROM expense_types ${includeInactive ? '' : 'WHERE is_active = ?'} ORDER BY name COLLATE NOCASE`, includeInactive ? [] : [1]);
        return sendJson(response, 200, { items: list.map((row) => ({ ...row, id: Number(row.id), is_active: Boolean(row.is_active) })) });
      }

      if (request.method === 'POST' && pathname === '/api/expense-types') {
        const auth = await requireAuth(db, request, response, true);
        if (!auth || !requireAdmin(auth, response)) return;
        const input = await readJson(request);
        const name = nonEmpty(input.name, 'Expense type', 80);
        const existing = await db.one('SELECT id FROM expense_types WHERE LOWER(name) = LOWER(?)', [name]);
        if (existing) return apiError(response, 409, 'This expense type already exists.');
        const created = await db.one('INSERT INTO expense_types (name, is_active, created_at, updated_at) VALUES (?, ?, ?, ?) RETURNING id, name, is_active, created_at, updated_at', [name, 1, now(), now()]);
        await logAudit(db, auth.user.id, 'CREATE', 'expense_type', created.id, { name });
        return sendJson(response, 201, { item: { ...created, id: Number(created.id), is_active: Boolean(created.is_active) } });
      }

      const typeMatch = pathname.match(/^\/api\/expense-types\/(\d+)$/);
      if (typeMatch && request.method === 'PATCH') {
        const auth = await requireAuth(db, request, response, true);
        if (!auth || !requireAdmin(auth, response)) return;
        const input = await readJson(request);
        if (typeof input.is_active !== 'boolean') return apiError(response, 400, 'Active status is required.');
        const id = Number(typeMatch[1]);
        const item = await db.one('UPDATE expense_types SET is_active = ?, updated_at = ? WHERE id = ? RETURNING id, name, is_active, created_at, updated_at', [input.is_active ? 1 : 0, now(), id]);
        if (!item) return apiError(response, 404, 'Expense type was not found.');
        await logAudit(db, auth.user.id, input.is_active ? 'ACTIVATE' : 'DEACTIVATE', 'expense_type', id, { name: item.name });
        return sendJson(response, 200, { item: { ...item, id: Number(item.id), is_active: Boolean(item.is_active) } });
      }

      if (request.method === 'GET' && pathname === '/api/expenses') {
        const auth = await requireAuth(db, request, response);
        if (!auth) return;
        const filter = getExpenseFilters(url);
        const rows = await db.all(`${EXPENSE_FIELDS}${filter.where} ORDER BY e.expense_date DESC, e.id DESC LIMIT 500`, filter.params);
        const total = await db.one(`SELECT COALESCE(SUM(e.amount_paisa), 0) AS total FROM expenses e JOIN expense_types t ON t.id = e.expense_type_id${filter.where}`, filter.params);
        return sendJson(response, 200, { items: rows.map(serializeExpense), total_paisa: Number(total.total), filter: { range: filter.range, from: filter.from, to: filter.to, search: filter.search } });
      }

      if (request.method === 'POST' && pathname === '/api/expenses') {
        const auth = await requireAuth(db, request, response, true);
        if (!auth) return;
        const data = validateExpense(await readJson(request));
        await activeTypeOrError(db, data.expense_type_id);
        const stamp = now();
        const created = await db.one(`INSERT INTO expenses (expense_date, expense_type_id, description, amount_paisa, payment_method, paid_to, note, external_ref, created_at, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?) RETURNING id`, [...Object.values(data), crypto.randomUUID(), stamp, stamp]);
        await logAudit(db, auth.user.id, 'CREATE', 'expense', created.id);
        const item = await db.one(`${EXPENSE_FIELDS} WHERE e.id = ?`, [created.id]);
        return sendJson(response, 201, { message: 'Expense saved successfully.', item: serializeExpense(item) });
      }

      const expenseMatch = pathname.match(/^\/api\/expenses\/(\d+)$/);
      if (expenseMatch && request.method === 'GET') {
        const auth = await requireAuth(db, request, response);
        if (!auth) return;
        const item = await db.one(`${EXPENSE_FIELDS} WHERE e.id = ?`, [Number(expenseMatch[1])]);
        if (!item) return apiError(response, 404, 'Expense was not found.');
        return sendJson(response, 200, { item: serializeExpense(item) });
      }
      if (expenseMatch && request.method === 'PUT') {
        const auth = await requireAuth(db, request, response, true);
        if (!auth) return;
        const id = Number(expenseMatch[1]);
        const data = validateExpense(await readJson(request));
        await activeTypeOrError(db, data.expense_type_id);
        const updated = await db.one(`UPDATE expenses SET expense_date = ?, expense_type_id = ?, description = ?, amount_paisa = ?, payment_method = ?, paid_to = ?, note = ?, updated_at = ?
          WHERE id = ? RETURNING id`, [...Object.values(data), now(), id]);
        if (!updated) return apiError(response, 404, 'Expense was not found.');
        await logAudit(db, auth.user.id, 'UPDATE', 'expense', id);
        const item = await db.one(`${EXPENSE_FIELDS} WHERE e.id = ?`, [id]);
        return sendJson(response, 200, { message: 'Expense updated successfully.', item: serializeExpense(item) });
      }
      if (expenseMatch && request.method === 'DELETE') {
        const auth = await requireAuth(db, request, response, true);
        if (!auth) return;
        const id = Number(expenseMatch[1]);
        const existing = await db.one(`${EXPENSE_FIELDS} WHERE e.id = ?`, [id]);
        if (!existing) return apiError(response, 404, 'Expense was not found.');
        await db.transaction(async (tx) => {
          await logAudit(tx, auth.user.id, 'DELETE', 'expense', id, { expense_date: normalDate(existing.expense_date), amount_paisa: Number(existing.amount_paisa), description: existing.description });
          await tx.run('DELETE FROM expenses WHERE id = ?', [id]);
        });
        return sendJson(response, 200, { message: 'Expense deleted.' });
      }

      if (request.method === 'GET' && pathname === '/api/reports/monthly') {
        const auth = await requireAuth(db, request, response);
        if (!auth) return;
        const month = url.searchParams.get('month') || dateInTimezone().slice(0, 7);
        if (!/^\d{4}-(0[1-9]|1[0-2])$/.test(month)) return apiError(response, 400, 'Choose a valid month.');
        const from = `${month}-01`;
        const until = nextMonth(month);
        const where = 'WHERE e.expense_date >= ? AND e.expense_date < ?';
        const params = [from, until];
        const [summary, visa, items] = await Promise.all([
          totals(db, where, params),
          db.one(`SELECT COALESCE(SUM(e.amount_paisa), 0) AS total FROM expenses e JOIN expense_types t ON t.id = e.expense_type_id ${where} AND t.name = ?`, [...params, 'Visa Fee']),
          db.all(`${EXPENSE_FIELDS} ${where} ORDER BY e.expense_date DESC, e.id DESC`, params)
        ]);
        return sendJson(response, 200, { month, total_paisa: summary.total, visa_fee_paisa: Number(visa.total), payment_totals: summary.payments, items: items.map(serializeExpense) });
      }

      if (request.method === 'GET' && pathname === '/api/backup') {
        const auth = await requireAuth(db, request, response);
        if (!auth) return;
        const format = url.searchParams.get('format') || 'json';
        if (!['json', 'csv'].includes(format)) return apiError(response, 400, 'Backup format must be JSON or CSV.');
        const [typeRows, expenseRows] = await Promise.all([
          db.all('SELECT id, name, is_active, created_at, updated_at FROM expense_types ORDER BY id'),
          db.all(`${EXPENSE_FIELDS} ORDER BY e.id`)
        ]);
        const dateStamp = dateInTimezone();
        if (format === 'json') {
          const backup = {
            backup_version: 1,
            application: 'Office Expense Ledger',
            exported_at: now(),
            expense_types: typeRows.map((row) => ({ name: row.name, is_active: Boolean(row.is_active), created_at: row.created_at, updated_at: row.updated_at })),
            expenses: expenseRows.map(expenseToBackup)
          };
          return sendText(response, 200, JSON.stringify(backup, null, 2), 'application/json; charset=utf-8', { 'Content-Disposition': `attachment; filename="office-expense-ledger-${dateStamp}.json"`, 'Cache-Control': 'no-store' });
        }
        const header = ['Date', 'Expense Type', 'Description', 'Amount BDT', 'Payment Method', 'Paid To', 'Note', 'Reference'];
        const lines = expenseRows.map((row) => {
          const item = serializeExpense(row);
          return [item.expense_date, item.expense_type, item.description, (item.amount_paisa / 100).toFixed(2), item.payment_method, item.paid_to, item.note, item.external_ref].map(csvValue).join(',');
        });
        return sendText(response, 200, `\uFEFF${header.join(',')}\r\n${lines.join('\r\n')}\r\n`, 'text/csv; charset=utf-8', { 'Content-Disposition': `attachment; filename="office-expense-ledger-${dateStamp}.csv"`, 'Cache-Control': 'no-store' });
      }

      if (request.method === 'POST' && pathname === '/api/backup/import') {
        const auth = await requireAuth(db, request, response, true);
        if (!auth || !requireAdmin(auth, response)) return;
        const result = await importBackup(db, auth.user.id, await readJson(request));
        return sendJson(response, 200, { message: `Backup restored: ${result.imported} added, ${result.skipped} duplicate entries skipped.`, ...result });
      }

      if (request.method === 'POST' && pathname === '/api/settings/password') {
        const auth = await requireAuth(db, request, response, true);
        if (!auth) return;
        const input = await readJson(request);
        const currentPassword = nonEmpty(input.current_password, 'Current password', 200);
        const newPassword = nonEmpty(input.new_password, 'New password', 200);
        if (newPassword.length < 10) return apiError(response, 400, 'New password must be at least 10 characters long.');
        const user = await db.one('SELECT password_hash FROM users WHERE id = ?', [auth.user.id]);
        if (!(await passwordMatches(currentPassword, user.password_hash))) return apiError(response, 401, 'Current password is incorrect.');
        await db.run('UPDATE users SET password_hash = ?, updated_at = ? WHERE id = ?', [await hashPassword(newPassword), now(), auth.user.id]);
        await db.run('DELETE FROM sessions WHERE user_id = ? AND id_hash <> ?', [auth.user.id, auth.session.id_hash]);
        await logAudit(db, auth.user.id, 'PASSWORD_CHANGE', 'user', auth.user.id);
        return sendJson(response, 200, { message: 'Password updated. Other devices have been logged out.' });
      }

      return apiError(response, 404, 'Page or API endpoint was not found.');
    } catch (error) {
      if (response.headersSent) return response.end();
      const status = Number(error.status) || 500;
      if (status >= 500) console.error(`[${now()}] Request failed:`, error.message);
      return apiError(response, status, status >= 500 ? 'Something went wrong. Please try again.' : error.message);
    }
  }

  return { server: http.createServer(handler), db };
}

async function start() {
  const app = await createApp();
  app.server.listen(config.port, () => console.log(`Office Expense Ledger is running at http://localhost:${config.port}`));
  const close = async () => { app.server.close(); await app.db.close(); process.exit(0); };
  process.on('SIGINT', close);
  process.on('SIGTERM', close);
}

if (require.main === module) start().catch((error) => { console.error(`Unable to start: ${error.message}`); process.exit(1); });

module.exports = { createApp, config };
