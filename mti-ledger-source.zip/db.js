const fs = require('node:fs');
const path = require('node:path');
const { DatabaseSync } = require('node:sqlite');

function postgresSql(sql) {
  let number = 0;
  return sql.replace(/\?/g, () => `$${++number}`);
}

class SqliteDatabase {
  constructor(filename) {
    this.kind = 'sqlite';
    this.connection = new DatabaseSync(filename);
    this.connection.exec('PRAGMA foreign_keys = ON; PRAGMA journal_mode = WAL; PRAGMA busy_timeout = 5000;');
  }

  async exec(sql) {
    this.connection.exec(sql);
  }

  async one(sql, params = []) {
    return this.connection.prepare(sql).get(...params) || null;
  }

  async all(sql, params = []) {
    return this.connection.prepare(sql).all(...params);
  }

  async run(sql, params = []) {
    return this.connection.prepare(sql).run(...params);
  }

  async transaction(callback) {
    this.connection.exec('BEGIN IMMEDIATE');
    try {
      const value = await callback(this);
      this.connection.exec('COMMIT');
      return value;
    } catch (error) {
      this.connection.exec('ROLLBACK');
      throw error;
    }
  }

  async close() {
    this.connection.close();
  }
}

class PostgresExecutor {
  constructor(client) {
    this.client = client;
    this.kind = 'postgres';
  }

  async exec(sql) {
    await this.client.query(sql);
  }

  async one(sql, params = []) {
    const result = await this.client.query(postgresSql(sql), params);
    return result.rows[0] || null;
  }

  async all(sql, params = []) {
    const result = await this.client.query(postgresSql(sql), params);
    return result.rows;
  }

  async run(sql, params = []) {
    return this.client.query(postgresSql(sql), params);
  }
}

class PostgresDatabase extends PostgresExecutor {
  constructor(pool) {
    super(pool);
    this.pool = pool;
  }

  async transaction(callback) {
    const client = await this.pool.connect();
    const tx = new PostgresExecutor(client);
    try {
      await client.query('BEGIN');
      const value = await callback(tx);
      await client.query('COMMIT');
      return value;
    } catch (error) {
      await client.query('ROLLBACK');
      throw error;
    } finally {
      client.release();
    }
  }

  async close() {
    await this.pool.end();
  }
}

function sqliteFilename(url, rootDir) {
  const value = url.slice('sqlite:'.length);
  if (value === ':memory:') return value;
  const filename = path.resolve(rootDir, value || './data/ledger.db');
  fs.mkdirSync(path.dirname(filename), { recursive: true });
  return filename;
}

async function connectDatabase(databaseUrl, rootDir) {
  if (!databaseUrl || databaseUrl.startsWith('sqlite:')) {
    return new SqliteDatabase(sqliteFilename(databaseUrl || 'sqlite:./data/ledger.db', rootDir));
  }
  if (databaseUrl.startsWith('postgres://') || databaseUrl.startsWith('postgresql://')) {
    let pg;
    try {
      pg = await import('pg');
    } catch {
      throw new Error('PostgreSQL mode needs the pg package. Run npm install before starting the app.');
    }
    const Pool = pg.Pool || pg.default?.Pool;
    const ssl = process.env.PGSSL === 'true' ? { rejectUnauthorized: false } : process.env.PGSSL === 'false' ? false : undefined;
    const pool = new Pool({ connectionString: databaseUrl, ssl });
    await pool.query('SELECT 1');
    return new PostgresDatabase(pool);
  }
  throw new Error('DATABASE_URL must start with sqlite:, postgres://, or postgresql://');
}

async function runMigrations(db, rootDir) {
  const filename = db.kind === 'postgres' ? '001_postgres.sql' : '001_sqlite.sql';
  const migration = fs.readFileSync(path.join(rootDir, 'migrations', filename), 'utf8');
  await db.exec(migration);
}

module.exports = { connectDatabase, runMigrations };
