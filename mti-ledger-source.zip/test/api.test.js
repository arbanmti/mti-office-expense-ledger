const test = require('node:test');
const assert = require('node:assert/strict');
const fs = require('node:fs');
const path = require('node:path');

const dbFile = path.join(__dirname, '..', 'data', 'test-ledger.db');
fs.rmSync(dbFile, { force: true });
process.env.DATABASE_URL = 'sqlite:./data/test-ledger.db';
process.env.SESSION_SECRET = 'test-session-secret-that-is-long-enough';
process.env.SECRET_KEY = 'test-secret-key-that-is-long-enough';
const { createApp } = require('../server');

function cookieFrom(response, name) {
  const all = response.headers.getSetCookie();
  const match = all.find((item) => item.startsWith(`${name}=`));
  return match.split(';')[0];
}

async function request(base, endpoint, options = {}) {
  const response = await fetch(`${base}${endpoint}`, options);
  const body = await response.json();
  return { response, body };
}

test('secure setup, ledger actions, report, and idempotent backup restore', async () => {
  const app = await createApp();
  await new Promise((resolve) => app.server.listen(0, '127.0.0.1', resolve));
  const port = app.server.address().port;
  const base = `http://127.0.0.1:${port}`;

  try {
    const logo = await fetch(`${base}/assets/mti-logo.png`);
    assert.equal(logo.headers.get('content-type'), 'image/png');
    assert.ok((await logo.arrayBuffer()).byteLength > 1000);
    let result = await request(base, '/api/auth/status');
    assert.equal(result.body.needs_setup, true);
    const setupCookie = cookieFrom(result.response, 'ledger_setup');
    const setupToken = result.body.setup_token;
    result = await request(base, '/api/dashboard');
    assert.equal(result.response.status, 401);

    result = await request(base, '/api/auth/setup', {
      method: 'POST', headers: { 'content-type': 'application/json', cookie: setupCookie },
      body: JSON.stringify({ username: 'office-admin', password: 'VerySafePass123', setup_token: setupToken })
    });
    assert.equal(result.response.status, 201);
    const sessionCookie = cookieFrom(result.response, 'ledger_session');
    const csrf = result.body.csrf_token;

    result = await request(base, '/api/expense-types', { headers: { cookie: sessionCookie } });
    assert.equal(result.body.items.length, 1);
    assert.equal(result.body.items[0].name, 'Visa Fee');

    result = await request(base, '/api/expenses', {
      method: 'POST', headers: { 'content-type': 'application/json', cookie: sessionCookie },
      body: JSON.stringify({ expense_date: '2026-09-16', expense_type_id: 1, description: 'Should not save', amount: '1', payment_method: 'Cash' })
    });
    assert.equal(result.response.status, 403);

    result = await request(base, '/api/expense-types', {
      method: 'POST', headers: { 'content-type': 'application/json', cookie: sessionCookie, 'x-csrf-token': csrf },
      body: JSON.stringify({ name: 'Office Rent' })
    });
    assert.equal(result.response.status, 201);
    assert.equal(result.body.item.name, 'Office Rent');

    result = await request(base, '/api/expenses', {
      method: 'POST', headers: { 'content-type': 'application/json', cookie: sessionCookie, 'x-csrf-token': csrf },
      body: JSON.stringify({ expense_date: '2026-09-16', expense_type_id: 1, description: 'Malaysia Visa Application Fee', amount: '5000', payment_method: 'Bank', paid_to: 'VFS', note: 'Customer visa application' })
    });
    assert.equal(result.response.status, 201);
    const expenseId = result.body.item.id;
    assert.equal(result.body.item.amount_paisa, 500000);

    result = await request(base, `/api/expenses/${expenseId}`, {
      method: 'PUT', headers: { 'content-type': 'application/json', cookie: sessionCookie, 'x-csrf-token': csrf },
      body: JSON.stringify({ expense_date: '2026-09-16', expense_type_id: 1, description: 'Malaysia Visa Application Fee — updated', amount: '5250', payment_method: 'Bank', paid_to: 'VFS', note: 'Customer visa application' })
    });
    assert.equal(result.response.status, 200);
    assert.equal(result.body.item.amount_paisa, 525000);

    result = await request(base, '/api/expenses?range=all', { headers: { cookie: sessionCookie } });
    assert.equal(result.body.items.length, 1);
    assert.equal(result.body.total_paisa, 525000);

    result = await request(base, '/api/reports/monthly?month=2026-09', { headers: { cookie: sessionCookie } });
    assert.equal(result.body.total_paisa, 525000);
    assert.equal(result.body.payment_totals.Bank, 525000);

    result = await request(base, '/api/backup?format=json', { headers: { cookie: sessionCookie } });
    assert.equal(result.body.expenses.length, 1);
    const backup = result.body;

    result = await request(base, `/api/expenses/${expenseId}`, { method: 'DELETE', headers: { cookie: sessionCookie, 'x-csrf-token': csrf } });
    assert.equal(result.response.status, 200);
    result = await request(base, '/api/backup/import', { method: 'POST', headers: { 'content-type': 'application/json', cookie: sessionCookie, 'x-csrf-token': csrf }, body: JSON.stringify(backup) });
    assert.equal(result.body.imported, 1);
    result = await request(base, '/api/backup/import', { method: 'POST', headers: { 'content-type': 'application/json', cookie: sessionCookie, 'x-csrf-token': csrf }, body: JSON.stringify(backup) });
    assert.equal(result.body.imported, 0);
    assert.equal(result.body.skipped, 1);
  } finally {
    await new Promise((resolve) => app.server.close(resolve));
    await app.db.close();
    fs.rmSync(dbFile, { force: true });
  }
});
