# Office Expense Ledger

একটি ছোট, দ্রুত ও নিরাপদ **Office Expense Ledger / অফিস খরচের ডিজিটাল টালি খাতা**। এই version শুধু expense রাখে—income, profit, invoice বা customer module ইচ্ছাকৃতভাবে নেই।

## কী কী আছে

- প্রথমবার browser থেকেই Admin account creation; কোনো hard-coded login নেই
- Password-এর জন্য salted `scrypt` hash; password বা sensitive session data browser storage-এ রাখা হয় না
- Secure, httpOnly, same-site session cookie; protected API/pages, CSRF verification, HTTP security headers এবং login rate limit
- Persistent SQLite database local development-এর জন্য; `DATABASE_URL` দিয়ে production PostgreSQL mode
- Default expense type শুধু **Visa Fee**; Admin নতুন type যোগ, activate/deactivate করতে পারেন
- Expense add, view, edit, delete এবং delete audit log
- Ledger search, Today/This Week/This Month/custom date range filters
- Dashboard, monthly report, per-payment-method actual totals
- JSON backup restore (duplicate-safe) এবং Excel-compatible CSV export
- বাংলা + English mixed, responsive interface

## প্রয়োজন

- Node.js **22.5+** (Node 24 recommended). Local SQLite mode-এর জন্য অন্য কোনো package দরকার নেই.
- Production PostgreSQL mode ব্যবহার করলে `npm install` চালাতে হবে, যাতে bundled `pg` dependency install হয়.

## Local setup

1. এই project folder-এ একটি local configuration file বানান:

   ```powershell
   Copy-Item .env.example .env
   ```

2. `.env`-এ development-এর জন্য এই value-গুলো রাখুন:

   ```dotenv
   DATABASE_URL=sqlite:./data/ledger.db
   SECRET_KEY=your-long-random-development-secret
   SESSION_SECRET=another-long-random-development-secret
   NODE_ENV=development
   PORT=3000
   APP_TIMEZONE=Asia/Dhaka
   ```

3. App চালান:

   ```powershell
   node server.js
   ```

4. Browser-এ `http://localhost:3000` খুলুন। প্রথমবারে **Create Admin Account** form আসবে। Account তৈরি করার পর থেকেই login করে কাজ করা যাবে.

Local data থাকে `data/ledger.db` file-এ। App/browser বন্ধ, refresh, computer restart বা logout হলেও সেই database file অক্ষত থাকলে expense data থাকবে। এই database file git-এর বাইরে রাখা হয়েছে।

## Admin account

প্রথম setup-এর সময়ই একমাত্র Admin account তৈরি করা যায়। Username 3–50 character এবং password অন্তত 10 character হতে হবে। Setup শেষ হলে একই screen আর দেখা যাবে না; এরপর normal login ব্যবহার করুন। Password পরিবর্তন করতে **Settings** page ব্যবহার করুন।

## Database & migrations

Startup-এর সময় safe, repeatable migration স্বয়ংক্রিয়ভাবে চলে:

- [SQLite migration](migrations/001_sqlite.sql)
- [PostgreSQL migration](migrations/001_postgres.sql)

Tables: `users`, `expense_types`, `expenses`, `sessions`, এবং `audit_logs`। টাকা floating point-এ না রেখে `expenses.amount_paisa` integer হিসেবে রাখা হয়: `500000` = `৳ 5,000.00`। এটি sum/report-এ rounding error এড়ায়।

## Backup and restore

**Backup** page থেকে:

- **Download JSON Backup**: সম্পূর্ণ restore-able backup। নিয়মিত এটি নিরাপদ cloud drive বা external drive-এ রাখুন।
- **Download Excel-compatible CSV**: Excel-এ দেখা/analysis করার file।
- **Import JSON Backup**: এই app-এর export করা JSON upload করুন। প্রতিটি expense-এর permanent reference দেখে duplicate record skip হয়। নতুন expense type থাকলে তা তৈরি হয়।

Restore করার আগে বর্তমান data-ও JSON হিসেবে download করে রাখা ভালো। JSON backup-এ password এবং login session থাকে না।

## Production deployment

Production-এ temporary filesystem-এর SQLite ব্যবহার করবেন না। তার বদলে managed, persistent PostgreSQL ব্যবহার করুন। Application code একই থাকে; শুধু environment variables বদলায়।

1. একটি persistent PostgreSQL database তৈরি করে connection URL নিন।
2. আপনার Node hosting service-এ এই repository deploy করুন এবং build/install command দিন:

   ```sh
   npm install
   ```

3. Start command দিন:

   ```sh
   node server.js
   ```

4. Hosting service-এর environment settings-এ দিন:

   ```dotenv
   NODE_ENV=production
   DATABASE_URL=postgresql://USER:PASSWORD@HOST:PORT/DATABASE?sslmode=require
   SECRET_KEY=long-random-secret-value
   SESSION_SECRET=a-different-long-random-secret-value
   APP_TIMEZONE=Asia/Dhaka
   PORT=3000
   APP_ORIGIN=https://your-ledger-subdomain.example
   ```

   PostgreSQL provider আলাদা SSL setting চাইলে `PGSSL=true` দিন; local/self-managed PostgreSQL SSL ছাড়া হলে `PGSSL=false` দিন.

5. প্রথম production visit-এ Admin account তৈরি করুন। Hosted database persistent হওয়ায় redeploy/restart হলেও data থাকবে। Migration এবং default Visa Fee category startup-এ নিজে থেকেই তৈরি হয়।

Hosting service সাধারণত একটি free subdomain দেয়; সেই URL-টি `APP_ORIGIN`-এ লিখুন। পরে custom domain যুক্ত করলে hosting service-এ domain/DNS add করে `APP_ORIGIN` নতুন `https://` URL-এ পরিবর্তন করুন। HTTPS ছাড়া production চালাবেন না—secure session cookie-এর জন্য HTTPS দরকার।

### Render Free + Supabase PostgreSQL

Project root-এর [render.yaml](render.yaml) Render Blueprint-ready। এটি `npm install`, `node server.js`, health check এবং production secrets automatic configure করে। Render Blueprint তৈরি করার সময় শুধু `DATABASE_URL` secret দিতে হবে—Supabase Dashboard-এর **Connect → Session pooler** থেকে পাওয়া PostgreSQL URL ব্যবহার করুন। `sslmode=require` URL-এ থাকলে রাখুন।

Render-এর free Node web service একটি `onrender.com` address দেয়। Free service 15 মিনিট inactivity-র পরে sleep করে, তাই প্রথম visit-এ একটু delay হতে পারে। Supabase Free project দীর্ঘ সময় ব্যবহার না হলে pause হতে পারে; গুরুত্বপূর্ণ হিসাবের জন্য নিয়মিত JSON backup রাখুন।

## Security notes

- `.env` কখনো git বা public repository-তে upload করবেন না।
- Production secrets random বানাতে পারেন:

  ```sh
  node -e "console.log(require('node:crypto').randomBytes(48).toString('base64url'))"
  ```

- `SESSION_SECRET` বদলালে existing login sessions শেষ হয়ে যাবে; expense data প্রভাবিত হবে না।
- Database provider-এর automated backup চালু রাখুন এবং app-এর JSON backup নিয়মিত রাখুন।

## Tests

Core API test setup/login, expense persistence actions, monthly totals, JSON export এবং duplicate-safe restore যাচাই করে:

```powershell
node --test test/api.test.js
```

## Project structure

```text
public/                 Browser UI
migrations/             SQLite and PostgreSQL schema
test/                   API integration test
server.js               Secure HTTP/API server
db.js                   SQLite/PostgreSQL data adapter
.env.example            Safe configuration template
```
